/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.primeiro_crud_wesley;

/**
 *
 * @author wpass
 */
public class Primeiro_crud_wesley {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
