CREATE DATABASE CRUD;
USE CRUD;

CREATE TABLE crud(
id_teclado INT PRIMARY KEY,
marca_teclado VARCHAR(45),
ano_fabricacao INT,
OitavasDoTeclado INT
);

SELECT * FROM crud;